#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"

/****************************************************
    Menu:
        1. Parse del archivo data.csv
        2. Listar Empleados
        3. Ordenar por nombre
        4. Agregar un elemento
        5. Elimina un elemento
        6. Listar Empleados (Desde/Hasta)
*****************************************************/


int main()
{
    Employee* aux1;
    Employee* aux2;
    int auxRespDesde;
    int auxRespHasta;
    Employee* auxListDesde;
    Employee* auxListHasta;
    int auxPos;
    int auxId=1001;
    char auxName[][51]={"luis"};
    char auxLastName[][51]={"figo"};
    int auxIsEmpty[]={1};

    char seguir='s';
    int opcion=0;
    int i;
    int resp;
    Employee* aux;
    ArrayList* listaEmpleados;
    ArrayList* lista2;
    FILE* archRegistro;


    while(seguir=='s')
    {
        printf("1- Cargar empleados\n");
        printf("2- Listar\n");
        printf("3- Ordenar\n");
        printf("4- Agregar empleado\n");
        printf("5- Eliminar empleado\n");
        printf("6- \n");
        printf("7- Salir\n");


        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            listaEmpleados = al_newArrayList();
            lista2=al_newArrayList();
            if(listaEmpleados!=NULL)
            {
                archRegistro=fopen("C:\\Users\\alumno\\Desktop\\Practica_Pair_v1.2\\Windows_64\\data.csv","r");
                parserEmployee(archRegistro,listaEmpleados);
                fclose(archRegistro);
                printf("cantidad de elementos: %d\n",listaEmpleados->len(listaEmpleados));
            }
            else
            {
                printf("NO se encontro lugar %d\n");
            }

            break;
        case 2:
            for(i=0; i<listaEmpleados->len(listaEmpleados); i++)
            {
                aux=(Employee*)listaEmpleados->get(listaEmpleados,i);
                employee_print(aux);


            }
                break;
            case 3:
                printf("ordenamiento (0)decreciente,(1)creciente");
                scanf("%d",&resp);
                al_sort(listaEmpleados,employee_compare,resp);
                 for(i=0; i<listaEmpleados->len(listaEmpleados); i++)
            {
                aux=(Employee*)listaEmpleados->get(listaEmpleados,i);
                employee_print(aux);

            }
                break;
            case 4:
                aux=employee_new();
                aux->id=auxId;
                aux->isEmpty=auxIsEmpty;
                strcpy(aux->name,auxName);
                strcpy(aux->lastName,auxLastName);
                al_add(listaEmpleados,aux);

                break;
            case 5:
                printf("q id desea eliminar:");
                scanf("%d",&resp);
                aux=al_pop(listaEmpleados,resp-1);
                employee_print(aux);
                break;
            case 6:
                printf("ingrese primer id ");
                scanf("%d",&auxRespDesde);
                printf("ingrese segundo id ");
                scanf("%d",&auxRespHasta+1);
                listaEmpleados=al_sort(auxListDesde,auxListHasta);



                for(i=0;i<listaEmpleados->len(listaEmpleados); i++)
                {
                        aux1=al_get(listaEmpleados,i )
                    if( auxRespDesde == aux1->id)
                        break;

                        aux2=al_get(listaEmpleados,i )
                    if( auxRespDesde == aux2->id)
                        break;
                }
                auxListDesde=al_indexOf(listaEmpleados,aux1->id)
                auxListHasta=al_indexOf(listaEmpleados,aux2->id)
                lista2=al_subList(listaEmpleados,auxListDesde,auxListHasta);

                 for(i=0; i<listaEmpleados->len(listaEmpleados); i++)
            {
                aux=(Employee*)lista2->get(lista2,i);
                employee_print(aux);
            }



                break;
            case 7:
                seguir = 'n';
                break;
            default:
                printf("opcion invalida");
                system("cls");
                break;
            }
        }

        return 0;
    }

