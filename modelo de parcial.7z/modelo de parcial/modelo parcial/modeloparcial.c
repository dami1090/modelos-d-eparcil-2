#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "modeloparcial.h"

int parserProducto(FILE* pFile, ArrayList* pArrayListProducto)
{
    char auxCodigo[10], auxEstado[10],auxPrecio[10];
    char auxDescrip[100],auxCantidad[100];
    eProducto* producto;
    fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",auxCodigo,auxDescrip,auxPrecio,auxCantidad,auxEstado);
    while(!feof(pFile))
    {
        fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",auxCodigo,auxDescrip,auxPrecio,auxCantidad,auxEstado);

        producto=producto_new();
        producto->codigoProducto=atoi(auxCodigo);
        producto->importe=atof(auxPrecio);
        producto->cantidad=atoi(auxCantidad);
        strcpy(producto->descrip,auxDescrip);



        pArrayListProducto->add(pArrayListProducto,producto);

    }

    return 0;
}




eProducto* producto_new(void)
{

    eProducto* returnAux = (eProducto*)calloc(1,sizeof(eProducto));

    return returnAux;

}

void producto_print(eProducto* lista)
{
    printf("%d--%s--%d--%d--%d\n",lista->codigoProducto,lista->descrip,lista->importe,lista->cantidad,lista->activo);
}

