#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "modeloparcial.h"
//https://www.mockaroo.com/
//http://www.utnfravirtual.org.ar/pluginfile.php/41991/mod_page/content/13/Parcial_2_Lab_I_A2015_C1.pdf

int main()
{


    int aux;
    char seguir='s';
    int opcion=0;
    int i;
    int resp;


    ArrayList* lista2;
    FILE* archRegistro;

    while(seguir=='s')
    {
        printf("1- Cargar productos\n");
        printf("2- Listar\n");
        printf("3- Ordenar\n");
        printf("4- Agregar producto\n");
        printf("5- Eliminar producto\n");
        printf("6- \n");
        printf("7- Salir\n");


        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            lista2=al_newArrayList();

            if(lista2!=NULL)
            {
                archRegistro=fopen("C:\\Users\\alumno\\Desktop\\modelo de parcial\\modelo parcial\\MOCK_DATA.csv","r");
                parserProducto(archRegistro,lista2);
                fclose(archRegistro);
                printf("cantidad de elementos: %d\n",lista2->len(lista2));
            }
            else
            {
                printf("NO se encontro lugar %d\n");
            }

            break;
        case 2:
            for(i=0; i<lista2->len(lista2); i++)
                {
                aux=(eProducto*)lista2->get(lista2,i);
                producto_print(aux);
                }
                break;
            case 3:

                break;
            case 4:


                break;
            case 5:

                break;
            case 6:

                break;
            case 7:
                seguir = 'n';
                break;
            default:
                printf("opcion invalida  \n");
                system("pause");
                system("cls");
                break;
            }
        }

        return 0;
    }
